<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste Les Étudiants</title>
</head>
<body>
    <h1>Liste Les Étudiants</h1>
    <!-- <?php 
    echo $nom;
    echo $prenom;
    ?>
    <br> -->
    {{$nom}}
    {{$prenom}}
</body>
</html>