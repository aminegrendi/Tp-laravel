<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class EtudiantController extends Controller
{
    public function index(){
        $nom='Grendi ';
        $prenom='Mohamed Amine';
        return view ('etudiant', compact('nom','prenom'));
    }
}
